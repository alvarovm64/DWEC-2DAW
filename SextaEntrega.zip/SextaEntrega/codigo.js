class ExcepcionesCarta {
  constructor(numero, palo) {
    if (numero < 1 || numero > 13) {
      throw new Error("El número no es correcto");
    }
    if (palo != "t" && palo != "r" && palo != "p" && palo != "c") {
      throw new Error("El palo no es correcto");
    }
  }
}

class Carta {
  constructor(numero = 1, palo = "c") {
    new ExcepcionesCarta(numero, palo);
    this.numero = numero;
    this.palo = palo;
    this.robada = false;
  }

  static copiar(carta) {
    let nuevaCarta = new Carta(carta.getNumero(), carta.getPalo());
    nuevaCarta.setRobada(carta.getRobada());
    return nuevaCarta;
  }

  getNumero() {
    return this.numero;
  }
  getPalo() {
    return this.palo;
  }
  getRobada() {
    return this.robada;
  }

  setNumero(numero) {
    new ExcepcionesCarta(numero, this.palo);
    this.numero = numero;
  }

  setPalo(palo) {
    new ExcepcionesCarta(this.numero, palo);
    this.palo = palo;
  }

  setRobada(robada) {
    this.robada = robada;
  }
}

class Baraja {
  constructor() {
    this.cartas = [];
    const palos = ["c", "r", "p", "t"];

    for (let p of palos) {
      for (let i = 1; i <= 13; i++) {
        this.cartas.push(new Carta(i, p));
      }
    }
  }

  robar() {
    let cartaEncontrada = null;
    for (let i = 0; i < this.cartas.length; i++) {
      if (!this.cartas[i].getRobada()) {
        cartaEncontrada = this.cartas[i];
        cartaEncontrada.setRobada(true);
        break;
      }
    }
    if (cartaEncontrada != null) {
      return Carta.copiar(cartaEncontrada);
    }
    return null;
  }

  numCartas() {
    let cartasSinRobar = 0;
    for (let i = 0; i < this.cartas.length; i++) {
      if (!this.cartas[i].getRobada()) {
        cartasSinRobar++;
      }
    }
    return cartasSinRobar;
  }

  barajar() {
    for (let i = this.cartas.length - 1; i > 0; i--) {
      let j = Math.floor(Math.random() * (i + 1));
      let cartaAux = this.cartas[i];
      this.cartas[i] = this.cartas[j];
      this.cartas[j] = cartaAux;
    }
  }

  cortar() {
    let indiceCorte = Math.floor(Math.random() * this.cartas.length);
    let bloque1 = this.cartas.slice(0, indiceCorte);
    let bloque2 = this.cartas.slice(indiceCorte);
    this.cartas = bloque2.concat(bloque1);
  }
}

let baraja = null;

function crearBaraja() {
  baraja = new Baraja();
  actualizarVistaMazo();
  document.getElementById("cartasRobadas").innerHTML = "";
}

function barajarMazo() {
  if (!baraja) return alert("Primero crea una baraja");
  baraja.barajar();
  alert("Mazo barajado");
}

function cortarMazo() {
  if (!baraja) return alert("Primero crea una baraja");
  baraja.cortar();
  alert("Mazo cortado");
}

function robarCarta() {
  if (!baraja) return alert("Primero crea una baraja");
  let carta = baraja.robar();

  if (carta) {
    let divRobadas = document.getElementById("cartasRobadas");
    let img = document.createElement("img");

    let nombreArchivo = `${carta.getPalo()}${carta.getNumero()}.jpg`;
    img.src = `baraja_francesa_52_cartas/${nombreArchivo}`;
    img.width = 80;

    divRobadas.appendChild(img);
    actualizarVistaMazo();
  } else {
    alert("No quedan más cartas en el mazo");
  }
}

function actualizarVistaMazo() {
  let restantes = baraja.numCartas();
  document.getElementById("infoMazo").innerText =
    "Cartas restantes en mazo: " + restantes;

  let contenedor = document.getElementById("contenedorMazo");
  if (restantes > 0) {
    contenedor.innerHTML = "Lomo de carta";
  } else {
    contenedor.innerHTML = "Mazo vacío";
  }
}